
///---------------------HEADER CODE BELOW----------------------///


import React from "react";

const Header = () =>
{
    return(

        <div className="header">LOGO</div>
    )
}

export default Header;