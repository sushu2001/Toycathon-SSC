import "./App.css";
import Footer from "./COMP/footer"
import Header from "./COMP/Header copy";
import CarouselContainer from "./carousel/Carousel";
import ImageSlider from "./carousel/Carousel";
import SliderData from "./carousel/SliderData";
import React from "react";

function App() {
  return (   
   <>
    <Header/>
      <div className="App">
        <div className="sec1">
          <ImageSlider slides={SliderData} />
        </div>
        <div className="sec2">
          <h1 className="heading">
            The 100% Engagement <br /> Platform
          </h1>
          <br />
          <br />
          <h3 className="subheading">
            Find and create free gamified quizes and interactive
            <br />
            lessond to engage any learner
          </h3>
          <br />
          <br />
          <br />
          <br />
          <div className="linkdiv">
            <button className="signupbutton">Sign Up</button>
            <a className="learnlink">
              <b>
                Learn more <span>{">"}</span>
              </b>
            </a>
          </div>
        </div>
      </div>
      <Footer/>
    </>
  );
}

export default App;
