import React from 'react'

 const Header = () => {
  return (
    <div className="Header">
      <h3 className="Logo">SUSHMA</h3>

      <a href="#"className='ref'>Login</a>
      <a href="#" className='ref'>Register</a>
    </div>
  );
}

export default Header;