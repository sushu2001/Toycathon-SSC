

 const SliderData = [
   {
     image: "asset/1.jpg",
   },
   {
     image: "asset/2.jpg",
   },
   {
     image: "asset/3.jpg",
   },
   {
     image: "asset/4.jpg",
   },
   {
     image:"asset/5.jpg"   },
 ];

export default SliderData;